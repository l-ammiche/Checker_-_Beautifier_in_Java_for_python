package FileAnalyser;
	/**
	 * une classe d'exception personnalisee qui represente une situation o� un element specifique ne peut pas �tre trouve. Elle etend la classe RuntimeException, qui est une classe d'exception qui represente des erreurs qui ne sont pas necessairement detectables lors de la compilation.
	 * @author Mohamed ABDELLI
	 * @since 12-12-2023
	 */
public class ElementNotFoundException extends RuntimeException {
   
	private static final long serialVersionUID = -409678518709814696L;
	 /**
     * Cr�e une nouvelle instance de l'exception avec le message sp�cifi�.
     *
     * @param message Le message d'erreur � afficher.
     */
	public ElementNotFoundException(String message) {
        super(message);
    }
}

