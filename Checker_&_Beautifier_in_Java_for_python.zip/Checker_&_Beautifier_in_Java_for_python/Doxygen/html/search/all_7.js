var searchData=
[
  ['ispythonfile_0',['isPythonFile',['../class_file_explorer_1_1_directory_manager.html#ab6fbe07cad40ffe9386305330101bc0c',1,'FileExplorer::DirectoryManager']]]
];
