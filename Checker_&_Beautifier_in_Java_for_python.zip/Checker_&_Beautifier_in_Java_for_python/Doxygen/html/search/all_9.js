var searchData=
[
  ['main_0',['main',['../class_cli_mod_1_1_cli.html#aad48ebd062c836c6515410b32b3e4fb4',1,'CliMod.Cli.main()'],['../class_gui_mod_1_1_gui.html#a51cefc0c0d9dffb66f9469e4c3084941',1,'GuiMod.Gui.main()']]]
];
